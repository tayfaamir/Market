package items;

public enum DigitalDeviceType {
    laptop,
    phone,
    smartWatch
}

