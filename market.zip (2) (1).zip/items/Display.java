package items;

public class Display {

    private double size;
    private double ratio;
    private double density;
    //TODO

    public Display(double size, double ratio, double density) {
        this.size = size;
        this.ratio = ratio;
        this.density = density;
    }


    public double getSize() {
        return size;
    }

    public double getRatio() {
        return ratio;
    }

    public double getDensity() {
        return density;
    }

    public void setSize(double size) {
        this.size = size;
    }

    public void setRatio(double ratio) {
        this.ratio = ratio;
    }

    public void setDensity(double density) {
        this.density = density;
    }
    public double getSurfaceArea(){
        double b=Math.sqrt(this.size*this.size/(1+Math.pow(this.getRatio(),2)));
        double a=b*this.getRatio();
        return a*b;
    }
    public double getResolution(){

       return this.getSurfaceArea()*this.density;
    }
    public double getPrice(){
        return 1.5*this.getResolution()+500*this.getSurfaceArea();
    }

}
