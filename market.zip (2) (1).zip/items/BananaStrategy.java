package items;

public class BananaStrategy extends BatteryPriceStrategy{
    public BananaStrategy() {
    }

    @Override
    public double calculatePrice(Battery battery) {
        return 300*battery.getCapacity()+10000* battery.getLifeSpan();
    }
}
