package items;

import users.User;

public class Car extends Good {

    private  double factoryPrice;
    private  double distanceTraveled;
    private  int manufacturingYear;
    private  boolean hadAccident;


    public Car(String name, User user, double factoryPrice, double distanceTraveled, int manufacturingYear, boolean hadAccident) {
        super(name,user);

        this.factoryPrice = factoryPrice;
        this.distanceTraveled = distanceTraveled;
        this.manufacturingYear = manufacturingYear;
        this.hadAccident = hadAccident;

    }

    public double getFactoryPrice() {
        return factoryPrice;
    }

    public double getDistanceTraveled() {
        return distanceTraveled;
    }

    public int getManufacturingYear() {
        return manufacturingYear;
    }

    public boolean isHadAccident() {
        return hadAccident;
    }

    public void setFactoryPrice(double factoryPrice) {
        this.factoryPrice = factoryPrice;
    }

    public void setDistanceTraveled(double distanceTraveled) {
        this.distanceTraveled = distanceTraveled;
    }

    public void setManufacturingYear(int manufacturingYear) {
        this.manufacturingYear = manufacturingYear;
    }

    public void setHadAccident(boolean hadAccident) {
        this.hadAccident = hadAccident;
    }


    public double  getPrice(){

        if(this.isHadAccident()==true){
            return ((this.getFactoryPrice())/(this.getDistanceTraveled()/10000))*0.3-(1400-this.getManufacturingYear());
        }
        return ((this.getFactoryPrice())/(this.getDistanceTraveled()/10000))-(1400-this.getManufacturingYear());
    }
}

