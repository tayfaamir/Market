package items;

import users.User;

public class Banking extends Service {

    private AccountType type;

    private double ratio;

    private double accountPrice;

    public Banking(String name, User user, AccountType type, double ratio) {
        super(name,user);
        this.name=name;
        this.user=user;
        this.type = type;
        this.ratio = ratio;
        this.accountPrice = accountPrice;
    }


    public AccountType getType() {
        return type;
    }

    public double getRatio() {
        return ratio;
    }

    public double getAccountPrice() {
        return accountPrice;
    }

    public void setType(AccountType type) {
        this.type = type;
    }

    public void setRatio(double ratio) {
        this.ratio = ratio;
    }

    public void setAccountPrice(double accountPrice) {
        this.accountPrice = accountPrice;
    }

    public double getPrice(){
        return accountPrice;
    }

    public void applyProfit(){
        if(this.getType().equals(AccountType.saving)){
            user.setCredit(user.getCredit()+(4/100)*this.accountPrice*(getDuration()/2));
        }
        if(this.getType().equals(AccountType.current)){
            double i=Math.pow(1.02,user.getCart().size());
            user.setCredit(user.getCredit()+Math.pow(this.user.getTotalPrice(),i));
        }
        if(this.getType().equals(AccountType.deposit)){
            user.setCredit(user.getCredit()+(Math.sqrt(user.getCredit())/this.accountPrice)+this.getDuration());
        }
    }
}
