package items;

import users.User;

public class DigitalDevice extends Good {


    private int memory;
    private Battery battery;
    private Display display;
    private DigitalDeviceType type;

    public DigitalDevice(String name, User user, int memory, Battery battery, Display display, DigitalDeviceType type) {
        super(name,user);

        this.memory = memory;
        this.battery = battery;
        this.display = display;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public User getUser() {
        return user;
    }

    public int getMemory() {
        return memory;
    }

    public Battery getBattery() {
        return battery;
    }

    public Display getDisplay() {
        return display;
    }

    public DigitalDeviceType getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setMemory(int memory) {
        this.memory = memory;
    }

    public void setBattery(Battery battery) {
        this.battery = battery;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public void setType(DigitalDeviceType type) {
        this.type = type;
    }
    public double getPrice(){
        double typePrice=0;
        if(this.getType().equals(DigitalDeviceType.laptop)){typePrice=30000000;}
        if(this.getType().equals(DigitalDeviceType.smartWatch)){typePrice=3000000;}
        if(this.getType().equals(DigitalDeviceType.phone)){typePrice=10000000;}
        return (this.memory*memory/10)+this.battery.getPrice()+this.display.getPrice()+typePrice+this.getBatteryLife()*1000000;
    }
    public double  getBatteryLife(){
        return this.battery.getCapacity()/(this.display.getResolution()*0.0001);
    }
}
