package items;

import market.Market;
import users.User;

public class Product {
    static int productId=1000000;
    protected String name;
    protected User user;
    protected int id;
    protected Market market=Market.getInstance();

    //TODO

    public Product(String name,User user) {
        market.addProduct(this);
        this.name = name;
        this.user=user;
        this.id=productId;
        productId++;
        //TODO => Generate id
    }

    public double getPrice(){
        return 0;
    }

    // getters and setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public int getId() {
        return id;
    }





    public void setId(int id) {
        this.id = id;
    }

    public Market getMarket() {
        return market;
    }

    public void setMarket(Market market) {
        this.market = market;
    }
}
