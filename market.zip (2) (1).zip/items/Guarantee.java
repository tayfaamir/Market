package items;

import users.User;

public class Guarantee extends Service{



    private Good good;

    public Guarantee(String name, Good good, User user) {
        super(name,user);

        this.good = good;

    }

    public String getName() {
        return name;
    }

    public User getUser() {
        return user;
    }

    public Good getGood() {
        return good;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public void setGood(Good good) {
        this.good = good;
    }

    public double getPrice(){
        return this.good.getPrice()*this.getDuration()/1000;
    }
}
