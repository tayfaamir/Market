package items;
import users.User;
import java.util.List;

public class EducationalMaterial extends Good {


    private double price;
    private List prerequisites;
    private int publishingYear;


    public EducationalMaterial(String name, User user, double price, List prerequisites, int publishingYear) {
        super(name,user);


        this.price = price;
        this.prerequisites = prerequisites;
        this.publishingYear = publishingYear;
    }


    public int  getExperienceLevel(){

        return 0;
    }
     public double getPrice() {
        return price;
    }

    public List getPrerequisites() {
        return prerequisites;
    }

    public int getPublishingYear() {
        return publishingYear;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPrerequisites(List prerequisites) {
        this.prerequisites = prerequisites;
    }

    public void setPublishingYear(int publishingYear) {
        this.publishingYear = publishingYear;
    }

}
