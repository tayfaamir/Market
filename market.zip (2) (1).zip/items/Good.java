package items;

import users.User;

public class Good extends Product {

    /**
     * A subclass of product, should have three subclasses: Car, EducationalMaterial and DigitalDevice
     */

    public Good(String name, User user) {

        super(name, user);
    }

}
