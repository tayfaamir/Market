package items;

public class Battery {
    private double capacity;
    private double chargingSpeed;
    private int lifeSpan;
    private BatteryPriceStrategy strategy;


    public Battery(double capacity, double chargingSpeed, int lifeSpan, BatteryPriceStrategy strategy) {
        this.capacity = capacity;
        this.chargingSpeed = chargingSpeed;
        this.lifeSpan = lifeSpan;
        this.strategy = strategy;
    }


    public double getChargingTime(){
        return this.capacity/this.chargingSpeed;
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getChargingSpeed() {
        return chargingSpeed;
    }

    public void setChargingSpeed(double chargingSpeed) {
        this.chargingSpeed = chargingSpeed;
    }

    public int getLifeSpan() {
        return lifeSpan;
    }

    public void setLifeSpan(int lifeSpan) {
        this.lifeSpan = lifeSpan;
    }

    public BatteryPriceStrategy getStrategy() {
        return strategy;
    }

    public void setStrategy(BatteryPriceStrategy strategy) {
        this.strategy = strategy;
    }
    public double getPrice(){
       return this.getStrategy().calculatePrice(this);
    }
//TODO
}

