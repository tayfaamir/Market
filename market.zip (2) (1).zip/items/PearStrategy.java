package items;

public class PearStrategy extends BatteryPriceStrategy{
    public PearStrategy() {
    }

    @Override
    public double calculatePrice(Battery battery) {
        return (1000000/battery.getChargingTime())+150*battery.getCapacity();
    }
}
