package users;

import items.Product;

import java.util.LinkedList;

public class User {

    private String name;
    private long phoneNumber;
    private double credit;
    private int Id;
    static int user_id=1000000;

    private LinkedList<Product>cart=new LinkedList<>();

    public User(String name, long phoneNumber) {
        this.name=name;
        this.phoneNumber=phoneNumber;
        this.Id=user_id;
        user_id++;
    }

    public double getCredit() {

        return credit;
    }

    public int getId() {
        return this.Id;
    }

    public LinkedList<Product> getCart() {
        return this.cart;
    }

    public long getPhoneNumber() {
        return this.phoneNumber;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public void setId(int id) {
        Id = id;
    }

    public void setCart(LinkedList<Product> cart) {
        this.cart = cart;
    }

    public double getTotalPrice(){
       double i=0;
        for (int j = 0; j < this.cart.size(); j++) {
            i=i+cart.get(j).getPrice();
        }
        return i;
    }

    public void purchase(){
        for (int i = 0; i < cart.size(); i++) {
            cart.get(i).getMarket().purchaseProduct(this,this.cart.get(i));
        }
        this.cart.clear();
    }

}
