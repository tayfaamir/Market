package market;

import items.Good;
import items.Guarantee;
import items.Product;
import items.Service;
import users.User;

import java.util.ArrayList;
import java.util.List;

public class Market {

    /**
     * main class of the market
     */
    private List<User> users;
    private List<Product> products;

    /**
     * For market class, we will use Singleton design pattern.
     * Singleton is used when you want to have only one instance of a class in your entire program
     * In this exercise, all objects should use the instance of Market, so we need only one instance of
     * Market in our entire program. Hence , we make it Singleton.
     */
    private static Market market;

    public static Market getInstance() {
        if (market == null)
            market = new Market();
        return market;
    }

    private Market() {
        users = new ArrayList<User>();
        products = new ArrayList<Product>();
    }


    public User getUser(int id)  {

        for (int i = 0; i < users.size(); i++) {
if(users.get(i).getId()==id){
    return users.get(i);

}

        }
        System.out.println("couldn't find this user");
        return null;
    }

    public Product getProduct(int id) {

        for (int i = 0; i < products.size(); i++) {
            if(products.get(i).getId()==id){
                return products.get(i);

            }

        }
        System.out.println("couldn't find this product");
        return null;
    }


    public Good getGood(int id) {
        for (int i = 0; i < products.size(); i++) {
            if(id==products.get(i).getId()&&products.get(i) instanceof Good==true){
                return (Good) products.get(i);
            }

        }
        System.out.println("couldn't find this good");
        return null;
    }

    public Service getService(int id) {
        for (int i = 0; i < products.size(); i++) {
            if(id==products.get(i).getId()&&products.get(i) instanceof Service==true){
                return (Service) products.get(i);
            }

        }
        System.out.println("couldn't find this service");
        return null;
    }

    public void addProduct(Product product) {
        this.products.add(product);
    }

    public void addUser(User user) {
        this.users.add(user);
    }

    public void addToCart(int userID, int productID) {
        if(getUser(userID)!=null&&getProduct(productID)!=null){
            this.getUser(userID).getCart().add(getProduct(productID));
        }
        else {
            System.out.println("invalid ID");
            if(getProduct(productID)!=null&&getProduct(productID) instanceof Guarantee==true){
                System.out.println("product has not been added ");
            };
        }
    }

    public void purchaseProduct(User buyer, Product product) {

        buyer.setCredit(buyer.getCredit()-product.getPrice());

        product.setUser(buyer);
        //TODO
    }

    public List<User> getUsers() {
        return users;
    }

    public List<Product> getProducts() {
        return products;
    }
}
